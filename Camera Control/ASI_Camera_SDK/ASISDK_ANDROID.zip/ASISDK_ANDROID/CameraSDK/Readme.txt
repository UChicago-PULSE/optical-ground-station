/**************************************************
ZWO ASI Camera Android SDK v1.1
any question feel free contact us: jimmy.dong@zwoptical.com

what's new
1��add ASI533, ASI2600, ASI6200, ASI2400 driver.
2��fix some bugs in library.

NOTE:
     When camera in previewing or snap statu, we should not call getCameraProperty() method, it may casue some error.

***************************************************/


/**************************************************
ZWO ASI Camera Android SDK v1.0
any question feel free contact us: ray.jiang@zwoptical.com

what's new
1��fix some bugs in library.

NOTE:
     When camera in previewing or snap statu, we should not call getCameraProperty() method, it may casue some error.

***************************************************/


/**************************************************
ZWO ASI Camera Android SDK v0.2
any question feel free contact us: ray.jiang@zwoptical.com

what's new
1��add ASI120MM_S, ASI120MC_S driver.
2��fix some bugs in library.

NOTE:
     When camera in previewing or snap statu, we should not call getCameraProperty() method, it may casue some error.

***************************************************/

/**************************************************
ZWO ASI Camera Android SDK v0.1
any question feel free contact us:ray.jiang@zwoptical.com

1��native c++ sdk: include/ASICamera2.h, libs/*/libASICamera2.so, libusb-1.0.so
2��java sdk: libs/*
3��java sdk api docs: docs

Read include/ASICamera2.h, docs for more usage.

***************************************************/